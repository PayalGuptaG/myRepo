package com.db.awmd.challenge.sync;

public interface SyncLockFactory<LockObj> {

	SyncLock<LockObj> getSyncLock(LockObj lockObj);
}
