package com.db.awmd.challenge.sync;

import java.util.concurrent.ConcurrentMap;

import org.hibernate.validator.internal.util.ConcurrentReferenceHashMap;
import org.springframework.stereotype.Component;

@Component
public class SyncLockFactoryImpl<LockObj> implements SyncLockFactory<LockObj> {
	private static final int DEFAULT_INITIAL_CAPACITY = 16;
	private static final float DEFAULT_LOAD_FACTOR = 0.75f;
	private static final int DEFAULT_CONCURRENCY_LEVEL = 16;
	private static final ConcurrentReferenceHashMap.ReferenceType DEFAULT_REFERENCE_TYPE =
			ConcurrentReferenceHashMap.ReferenceType.WEAK;

	private final ConcurrentMap<LockObj, SyncLock<LockObj>> map;
	
	public SyncLockFactoryImpl() {
		this.map = new ConcurrentReferenceHashMap<>(DEFAULT_INITIAL_CAPACITY,
		                                            DEFAULT_LOAD_FACTOR,
		                                            DEFAULT_CONCURRENCY_LEVEL,
		                                            DEFAULT_REFERENCE_TYPE,
		                                            DEFAULT_REFERENCE_TYPE,
		                                            null);
	}

	@Override
	public SyncLock<LockObj> getSyncLock(LockObj lockObj){
		return this.map.computeIfAbsent(lockObj, SyncLock::new);
	}
}

