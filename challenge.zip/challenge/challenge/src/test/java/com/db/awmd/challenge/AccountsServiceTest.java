package com.db.awmd.challenge;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.fail;

import java.math.BigDecimal;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.domain.AccountTransactionInfo;
import com.db.awmd.challenge.exception.AssetManagementException;
import com.db.awmd.challenge.exception.DuplicateAccountIdException;
import com.db.awmd.challenge.service.AccountsService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AccountsServiceTest {

  @Autowired
  private AccountsService accountsService;

  @Test
  public void addAccount() throws Exception {
    Account account = new Account("Id-123");
    account.setBalance(new BigDecimal(1000));
    this.accountsService.createAccount(account);

    assertThat(this.accountsService.getAccount("Id-123")).isEqualTo(account);
  }

  @Test
  public void addAccount_failsOnDuplicateId() throws Exception {
    String uniqueId = "Id-" + System.currentTimeMillis();
    Account account = new Account(uniqueId);
    this.accountsService.createAccount(account);

    try {
      this.accountsService.createAccount(account);
      fail("Should have failed when adding duplicate account");
    } catch (DuplicateAccountIdException ex) {
      assertThat(ex.getMessage()).isEqualTo("Account id " + uniqueId + " already exists!");
    }

  }
  
  @Test
  public void transferFunds() throws Exception {
	  Account toAccount = new Account("Id-123");
	  toAccount.setBalance(new BigDecimal(1000));
	  this.accountsService.createAccount(toAccount);
	  
	  Account fromAccount = new Account("Id-124");
	  fromAccount.setBalance(new BigDecimal(2000));
	  this.accountsService.createAccount(fromAccount);
	  
	  AccountTransactionInfo acctTransactionInfo = new AccountTransactionInfo("Id-123","Id-124",new BigDecimal(500));
	  this.accountsService.transferFunds(acctTransactionInfo);

	  assertThat(this.accountsService.getAccount("Id-123").getBalance()).isEqualTo(new BigDecimal(500));
	  assertThat(this.accountsService.getAccount("Id-124").getBalance()).isEqualTo(new BigDecimal(2500));
  }
  
  @Test(expected = AssetManagementException.class)
  public void transferFunds_AssetManagementException(){
	  Account toAccount = new Account("Id-123");
	  toAccount.setBalance(new BigDecimal(1000));
	  this.accountsService.createAccount(toAccount);
	  
	  Account fromAccount = new Account("Id-124");
	  fromAccount.setBalance(new BigDecimal(2000));
	  this.accountsService.createAccount(fromAccount);
	  
	  AccountTransactionInfo acctTransactionInfo = new AccountTransactionInfo("Id-123","Id-124",new BigDecimal(2000));
	  this.accountsService.transferFunds(acctTransactionInfo);

  }
}
