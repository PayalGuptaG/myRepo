package com.db.awmd.challenge.sync;

import lombok.Data;

@Data
public class SyncLock<LockObj> {

	private final LockObj lockObj;
}
